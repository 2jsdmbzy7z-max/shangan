#!/bin/bash
# 上岸计划 —— 直接以「桌面 App 窗口」打开（macOS / Linux，无需联网/服务器/安装）
# 双击或在终端运行本文件，得到一个没有地址栏的独立 App 窗口
cd "$(dirname "$0")"
FILE="file://$PWD/index.html"

if [ -d "/Applications/Google Chrome.app" ]; then
  open -a "Google Chrome" --args --app="$FILE"
elif command -v google-chrome >/dev/null 2>&1; then
  google-chrome --app="$FILE"
elif command -v chromium >/dev/null 2>&1; then
  chromium --app="$FILE"
else
  echo "未检测到 Chrome，请先安装，或手动在浏览器打开：$FILE"
fi
