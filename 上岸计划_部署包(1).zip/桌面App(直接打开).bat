@echo off
REM 上岸计划 —— 直接以「桌面 App 窗口」打开（无需联网 / 无需服务器 / 无需安装）
REM 双击本文件即可获得一个没有地址栏的独立 App 窗口
cd /d "%~dp0"

set "FILE=file:///%CD:\=/%/index.html"

REM 尝试用 Chrome 以 App 模式打开
where chrome >nul 2>nul && (
  start "" chrome --app="%FILE%"
) || (
  where msedge >nul 2>nul && (
    start "" msedge --app="%FILE%"
  ) || (
    echo 未检测到 Chrome / Edge，请先安装浏览器。
    echo 也可手动在浏览器地址栏输入：%FILE%
    pause
  )
)
