@echo off
REM 上岸计划 —— 本地启动脚本（Windows）
REM 作用：在本机启动本地服务器并打开 App，随后点右上角「安装」即可生成桌面 App
cd /d "%~dp0"

set PORT=8000
set URL=http://localhost:%PORT%/index.html

REM 启动本地服务器（后台）
if exist "%SystemRoot%\py.exe" (
  start "" py -m http.server %PORT%
) else (
  where python >nul 2>nul && (
    start "" python -m http.server %PORT%
  ) || (
    where node >nul 2>nul && (
      start "" node -e "require('http').createServer((q,s)=>{const f=require('fs');const p='.'+(q.url==='/'?'/index.html':q.url);f.readFile(p,(e,d)=>{if(e){s.writeHead(404);s.end('nf')}else{s.writeHead(200);s.end(d)}})}).listen(%PORT%)"
    ) || (
      echo 未找到 python 或 node，请先安装其一后再运行本脚本。
      pause
      exit /b 1
    )
  )
)

REM 打开浏览器
timeout /t 1 >nul
start "" "%URL%"

echo 本地服务已启动：%URL%
echo 关闭此窗口即可停止服务。
cmd /k
