#!/bin/bash
# 上岸计划 —— 本地启动脚本（Mac / Linux / WSL）
# 作用：在本机启动一个本地服务器并打开 App，随后即可点右上角「安装」生成桌面 App
cd "$(dirname "$0")"

PORT=8000
URL="http://localhost:$PORT/index.html"

# 启动本地服务器（后台）
if command -v python3 &>/dev/null; then
  python3 -m http.server "$PORT" >/dev/null 2>&1 &
elif command -v python &>/dev/null; then
  python -m http.server "$PORT" >/dev/null 2>&1 &
elif command -v node &>/dev/null; then
  node -e "require('http').createServer((q,s)=>{const f=require('fs');const p='.'+ (q.url==='/'?'/index.html':q.url);f.readFile(p,(e,d)=>{if(e){s.writeHead(404);s.end('not found')}else{s.writeHead(200);s.end(d)}})}).listen($PORT)" >/dev/null 2>&1 &
else
  echo "未找到 python 或 node，请先安装其一，再双击本脚本。"
  read -p "按回车退出"
  exit 1
fi

# 打开浏览器
sleep 1
if command -v open &>/dev/null; then
  open "$URL"
elif command -v xdg-open &>/dev/null; then
  xdg-open "$URL"
else
  echo "请在浏览器中打开：$URL"
fi

echo "本地服务已启动：$URL  （关闭本窗口即可停止服务）"
wait
